# Web Development ABL Assignment

Replace the sample student details and content with your own information before submission.

## Selected case studies
1. Personal Portfolio Website
2. Student Academic Dashboard
3. User Registration and Login Interface

## Technologies
- HTML5
- CSS3

## How to run
Open the `index.html` file inside each case-study folder in a web browser.

## Important note
The student dashboard uses sample academic data. The registration and login pages are front-end demonstrations only; they do not store users or provide real authentication because no backend/database is connected.
